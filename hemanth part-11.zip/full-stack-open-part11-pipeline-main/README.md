# full-stack-open-part11-pipeline

This repository was used for creating deployment pipeline for exercises [11.21 and 11.22](https://fullstackopen.com/en/part11/expanding_further#exercises-11-20-11-22) of Full Stack Open 2021.

