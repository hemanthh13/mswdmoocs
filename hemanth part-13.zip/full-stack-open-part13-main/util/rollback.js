const { rollbackMigration } = require('./db');

rollbackMigration();
