## Exercises 12.21 and 12.22

Based on [part 7 bloglist application](https://github.com/mtuomiko/full-stack-open/tree/master/part7) (backend and frontend).

## Environment variables and secrets

Backend env vars `MONGODB_URI` and `SECRET` need to be defined in `backend/.env` file to use the docker-compose setup. See also [backend README.md](backend/README.md). It should be fine for this exercise since this `docker-compose` setup is not going to be actually running anywhere.
