module.exports = {
  globals: {
    "BACKEND_URL": true
  },
  setupFilesAfterEnv: ['./src/setupTests.js']
}