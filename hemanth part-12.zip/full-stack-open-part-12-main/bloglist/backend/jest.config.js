module.exports = {
  testEnvironment: 'node'
}